# qq_fanghong

## 引言

因为`github.io`自身就是自带QQ、微信防红的域名，所以是用来做防红接口的不错材料。

## 使用方法

进入该网址：[fanghong.yiove.com](https://fanghong.yiove.com)

搭建教程：[https://www.skyqian.com/archives/qq-weixin_fanghong.html](https://www.skyqian.com/archives/qq-weixin_fanghong.html)
